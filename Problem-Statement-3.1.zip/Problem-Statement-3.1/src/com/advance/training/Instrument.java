package com.advance.training;

public abstract class Instrument {
	
	public abstract void play();

}
