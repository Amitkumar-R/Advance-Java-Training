package com.advance.training;

public class Book {

	private String book_title;
	private double book_price;

	public String getBook_title() {
		return book_title;
	}

	public Book setBook_title(String book_title) {
		this.book_title = book_title;
		return null;
	}

	public double getBook_price() {
		return book_price;
	}

	public Book setBook_price(double book_price) {
		this.book_price = book_price;
		return null;
	}
	
}
