package com.advance.training;

import java.util.ArrayList;
import java.util.Scanner;

public class BookMain {
	
	String title;
	double price;
	Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		new BookMain().createBook();
	}
	
	public void createBook() {
		
		System.out.println("Enter the Book Name: ");
		title = sc.nextLine();
		
		System.out.println("Enter the Book Price: ");
		price = sc.nextDouble();
		sc.nextLine();
	
		Book bookObj = new Book();
		ArrayList<Book> listOfBooks = new ArrayList<Book>();
		listOfBooks.add(bookObj.setBook_title(title));
		listOfBooks.add(bookObj.setBook_price(price));

		listOfBooks.add(bookObj);
		
		System.out.println("Book Title" + "\t\t" + "Price");
		System.out.println(bookObj.getBook_title() + "\t" +  bookObj.getBook_price());
		
	}
	
	public static void showBook(ArrayList<Book> listOfBooks) {
		for(int i=0; i<listOfBooks.size(); i++) {
			System.out.println(listOfBooks.get(i));
		} 
		System.out.println();
	}

}
