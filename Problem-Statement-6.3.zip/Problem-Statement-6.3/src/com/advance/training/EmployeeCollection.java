package com.advance.training;

import java.util.Vector;

public class EmployeeCollection {

	public static void main(String[] args) {
		Vector<Employee> v = addInput();
		display(v);
	}
	
	public static Vector<Employee> addInput() {
		Employee e1 = new Employee(101, "Krishna", "Yadav");
		Employee e2 = new Employee(102, "Arjuna", "Pandava");
		Employee e3 = new Employee(103, "Duryodhana", "Kourav");
		
		Vector<Employee> v = new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}
	
	private static void display(Vector<Employee> v) {
		for(Employee e: v) {
			System.out.println(e.getEmployeeNo() + "\t" + e.getEmployeeName() + "\t" + e.getAddress());
		}
	}
	
}
