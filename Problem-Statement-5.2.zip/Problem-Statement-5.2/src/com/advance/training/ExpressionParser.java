package com.advance.training;

public class ExpressionParser {
	
	public static void main(String[] args) {
		String str = (" 24 + 45 - ( 343 / 12 ) ");
		args = str.split(" ");
		for(String args1 : args) {
			System.out.println(args1);
		}
	}

}
