package com.advance.training;

import java.util.Hashtable;
import java.util.Scanner;

public class Product {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		Hashtable<String, String> ht = new Hashtable<String, String>();
		for(int i = 0; i < 3; i++) {
			ht.put(sc.next(), sc.next());
		}
		
		System.out.println("The Product List is: ");
		System.out.println(ht);
		
		System.out.println("Enter the Product Id to be Removed: ");
		String id = sc.next();
		ht.remove(id);
		System.out.println("Item is removed");
		
		System.out.println("The Product List is: ");
		System.out.println(ht.toString());
		
		System.out.println("Enter the Product Id to be Searched: ");
		String pid = sc.next();
		
		if(ht.containsKey(pid)) {
			System.out.println(ht.get(pid));
		} else {
			System.out.println("Do not exist");
		}
	}

}
