package com.mycompany.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;

public class ProductManagementApp {
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static ProductManagementDAO prodDao = new ProductManagementDAO();

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {

		String option = "";
		
		do {
			System.out.println("A. View Products");
			System.out.println("B. Add Product");
			System.out.println("C. Update Product");
			System.out.println("D. Delete Product");
			System.out.println("E. Search Product");
			System.out.println("F. Exit");
			System.out.println("==============================");
			System.out.println("Enter an option");
			System.out.println("==============================");
			option = br.readLine();
			System.out.println("\n");
			
			switch (option) {
			case "A":
				viewProducts();
				break;

			case "B":
				addProduct();
				break;

			case "C":
				updateProduct();
				break;
				
			case "D":
				deleteProduct();
				break;
				
			case "E":
				searchProduct();
				break;

			case "F":
				System.out.println("***************THANK YOU***************");
				System.exit(0);
				break;

			default:
				break;
			}
		} while(!option.equals("F"));
	}

	// View products
	private static void viewProducts() throws ClassNotFoundException, SQLException {
		System.out.println("------------------------------");
		List<Product> prodList = prodDao.viewAllProducts();
		for(Product prod : prodList) {
			displayProduct(prod);
		}
	}
	
	// Add product
	private static void addProduct() throws IOException, ClassNotFoundException, SQLException {
		System.out.println("------------------------------");
		System.out.println("Enter Product Name: ");
		System.out.println("------------------------------");
		String prodName = br.readLine();
		System.out.println("------------------------------");
		System.out.println("Enter Product Id: ");
		System.out.println("------------------------------");
		String prodId = br.readLine();
		System.out.println("------------------------------");
		System.out.println("Enter Product Price: ");
		System.out.println("------------------------------");
		int prodPrice = Integer.parseInt(br.readLine());
		Product prod = new Product(prodId, prodName, prodPrice);
		int status = prodDao.addProduct(prod);
		if(status == 1) {
			System.out.println("Product addedd successfully");
		} else {
			System.out.println("Product insertion failed!");
		}
		System.out.println("\n");
	}
	
	// Update product
	private static void updateProduct() throws IOException, ClassNotFoundException, SQLException {
		System.out.println("------------------------------");
		System.out.println("Enter Product Name: ");
		System.out.println("------------------------------");
		String prodName = br.readLine();
		System.out.println("------------------------------");
		System.out.println("Enter Product Id: ");
		System.out.println("------------------------------");
		String prodId = br.readLine();
		System.out.println("------------------------------");
		System.out.println("Enter Product Price: ");
		System.out.println("------------------------------");
		int prodPrice = Integer.parseInt(br.readLine());
		Product prod = new Product(prodId, prodName, prodPrice);
		int status = prodDao.updateProduct(prod);
		if(status == 1) {
			System.out.println("Product updated successfully");
		} else {
			System.out.println("Product updation failed!");
		}
		System.out.println("\n");
	}
	
	// Delete product
	private static void deleteProduct() throws NumberFormatException, IOException, ClassNotFoundException, SQLException {
		System.out.println("------------------------------");
		System.out.println("Enter Product Id: ");
		System.out.println("------------------------------");
		String prodId = br.readLine();
		int status = prodDao.deleteProduct(prodId);
		if(status == 1) {
			System.out.println("Product deleted successfully");
		} else {
			System.out.println("Product deletion failed!");
		}
		System.out.println("\n");
	}
	
	// Search product
	private static void searchProduct() throws NumberFormatException, IOException, ClassNotFoundException, SQLException {
		System.out.println("------------------------------");
		System.out.println("Enter Product Id: ");
		System.out.println("------------------------------");
		String prodId = br.readLine();
		Product prod = prodDao.getProductById(prodId);
		displayProduct(prod);
	}
	
	public static void displayProduct(Product prod) {
		System.out.println("Product Name: " + prod.getProductName());
		System.out.println("Product Id: " + prod.getProductId());
		System.out.println("Product Price: " + prod.getProductPrice());
		System.out.println("\n");
	}

}
