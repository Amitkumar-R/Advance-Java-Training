package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAO {
	
	// View all products
	public List<Product> viewAllProducts() throws ClassNotFoundException, SQLException {
		List<Product> prodList = new ArrayList<Product>();
		Connection conn = DBUtil.dbConn();
		Statement statement = conn.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * FROM Product");
		while(rs.next()) {
			Product prod = new Product(rs.getString("productId"), rs.getString("productName"), rs.getInt("productPrice"));
			prodList.add(prod);
		}
		return prodList;
	}
	
	// View Product by Id
	public Product getProductById(String productId) throws ClassNotFoundException, SQLException {
		Product prod = null;
		Connection conn =  DBUtil.dbConn();
		String sql = "SELECT * FROM Product WHERE productId = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, productId);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			prod = new Product(rs.getString("productId"), rs.getString("productName"), rs.getInt("productPrice"));
		}
		return prod;
	}
	
	// Adding the product
	public int addProduct(Product prod) throws ClassNotFoundException, SQLException {
		int status = 0;
		Connection conn = DBUtil.dbConn();
		String sql = "INSERT INTO Product VALUES(?, ?, ?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, prod.getProductId());
		ps.setString(2, prod.getProductName());
		ps.setInt(3, prod.getProductPrice());
		status = ps.executeUpdate();
		return status;
	}
	
	// Update the Product
	public int updateProduct(Product prod) throws ClassNotFoundException, SQLException {
		int status = 0;
		Connection conn = DBUtil.dbConn();
		String sql = "update product set productName=?, productPrice=? where productId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, prod.getProductName());
		ps.setInt(2, prod.getProductPrice());
		ps.setString(3, prod.getProductId());
		status = ps.executeUpdate();
		return status;
	}
	
	// Delete the Product
	public int deleteProduct(String productId) throws ClassNotFoundException, SQLException {
		int status = 0;
		Connection conn = DBUtil.dbConn();
		String sql = "DELETE FROM Product WHERE productId = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, productId);
		status = ps.executeUpdate();
		return status;
	}
	
//	public int view() throws ClassNotFoundException, SQLException {
//		Connection conn = DBUtil.dbConn();
//		Statement stmt = conn.createStatement();
//		String sql = "select * from product";
//		ResultSet rs = stmt.executeQuery(sql);
//		while(rs.next()) {
//			System.out.println("\n\nProduct Name: " + rs.getString(1) + " \nProduct Id: " + rs.getInt(2) + " \nProduct Price: " + rs.getInt(3));
//		}
//		return 0;
//	}
//	
//	public int insert(Product prod) throws ClassNotFoundException, SQLException {
//		Connection conn = DBUtil.dbConn();
//		String sql = "insert into product values(?, ?, ?)";
//		PreparedStatement ps = conn.prepareStatement(sql);
//		ps.setString(1, prod.getProductName());
//		ps.setInt(2, prod.getProductId());
//		ps.setInt(3, prod.getProductPrice());
//		return ps.executeUpdate();
//	}
//	
//	public void update(Product prod) throws ClassNotFoundException, SQLException {
//		Connection conn = DBUtil.dbConn();
//		String sql = "update product set productName=? where productId=?";
//		PreparedStatement ps = conn.prepareStatement(sql);
//		ps.setString(1, prod.getProductName());
//		ps.setInt(2, prod.getProductId());
//		ps.executeUpdate();
//		System.out.println("Product updated successfully");
//	}
//	
//	public static int delete(String productId) throws ClassNotFoundException, SQLException {
//		int status = 0;
//		Connection conn = DBUtil.dbConn();
//		String sql = "delete from product where productId=?";
//		PreparedStatement ps = conn.prepareStatement(sql);
//		ps.setString(1, productId);
//		status = ps.executeUpdate();
//		return status;
//	}
//	
//	public void search(Product prod) throws ClassNotFoundException, SQLException {
//		Connection conn = DBUtil.dbConn();
//		String sql = "select * from product where productId=?";
//		PreparedStatement ps = conn.prepareStatement(sql);
//		ps.setInt(1, prod.getProductId());
//		ps.executeUpdate();
//	}

}
