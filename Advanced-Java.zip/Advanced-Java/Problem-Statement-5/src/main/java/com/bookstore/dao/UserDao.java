package com.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bookstore.entity.User;

public class UserDao {
	
	private Connection conn;
	
	public UserDao(Connection conn) {
		this.conn = conn;
	}
	
	public boolean saveUser(User user) {
		boolean f = false;
		try {
			String sql = "insert into users(first_name, address, email, user_name, password) values(?,?,?,?,?)";
			PreparedStatement ps = this.conn.prepareStatement(sql);
			ps.setString(1, user.getFirst_name());
			ps.setString(2, user.getAddress());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getUname());
			ps.setString(5, user.getPass());
			ps.executeUpdate();
			f = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return f;
	}
	
	public User getUserByUnameAndPassword(String uname, String password) {
		User user = null;
		try {
			String sql = "select * from users where user_name = ? and password = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, uname);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setFirst_name(rs.getString("fname"));
				user.setAddress(rs.getString("addres"));
				user.setEmail(rs.getString("email"));
				user.setUname(uname);
				user.setPass(rs.getString("password"));
				user.setRegDate(rs.getTimestamp("rdate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public User resetPassword(String email, String uname) {
		User user = null;
		try {
			String sql = "select * from users where email = ? and user_name = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, uname);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setFirst_name(rs.getString("fname"));
				user.setAddress(rs.getString("address"));
				user.setEmail(rs.getString("email"));
				user.setUname(uname);
				user.setPass(rs.getString("password"));
				user.setRegDate(rs.getTimestamp("rdate"));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public int setPassword(String pass) throws SQLException {
		String sql = "update users set password = ? where user_name = ?";
		User user = new User();
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, pass);
		ps.setString(2, (user.getUname()));
		return ps.executeUpdate();
	}

}
