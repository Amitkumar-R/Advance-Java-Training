package com.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bookstore.entity.User;

public class UserDao {
	
	private Connection conn;
	
	public UserDao(Connection conn) {
		this.conn = conn;
	}
	
	public boolean saveUser(User user) {
		boolean f = false;
		try {
			String sql = "insert into users(first_name, address, email, user_name, password) values(?,?,?,?,?)";
			PreparedStatement ps = this.conn.prepareStatement(sql);
			ps.setString(1, user.getFirst_name());
			ps.setString(2, user.getAddress());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getUname());
			ps.setString(5, user.getPass());
			ps.executeUpdate();
			f = true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return f;
	}
	
	public User getUserByUnameAndPassword(String uname, String password) {
		User user = null;
		try {
			String sql = "select * from users where user_name = ? and password = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, uname);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setFirst_name(rs.getString("fname"));
				user.setAddress(rs.getString("addres"));
				user.setEmail(rs.getString("email"));
				user.setUname(uname);
				user.setPass(rs.getString("password"));
				user.setRegDate(rs.getTimestamp("rdate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

}
