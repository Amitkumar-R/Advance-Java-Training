package com.advanec.training;

public class ArrayElements {
	
	static int a[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	
	static int sum() {
		int sum = 0;
		int i;
		
		for(i = 0; i < a.length - 4; i++) {
			sum = sum + a[i];
		}
		return sum;
	}
	
	static double avg(int a[], int n) {
		int sum = 0;
		for(int i = 0; i < n; i++) {
			sum += a[i];
		}
		return (double)sum/n;
	}
	
	static int smallest() {
		int min = a[0];
		for(int i = 0; i < a.length; i++) {
			if(a[i] < min) {
				min = a[i];
			}
		}
		return min;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The sum of array elements is: " + sum());
		a[15] = sum();
		System.out.println("The element present in 15th index is: " + a[15]);
		int n = a.length;
		System.out.println("The average of array elements is: " + avg(a, n));
		a[16] = (int) avg(a, n);
		System.out.println("The element present in 16th index is: " + a[16]);
		System.out.println("The smallest element in the array is: " + smallest());
	}

}
