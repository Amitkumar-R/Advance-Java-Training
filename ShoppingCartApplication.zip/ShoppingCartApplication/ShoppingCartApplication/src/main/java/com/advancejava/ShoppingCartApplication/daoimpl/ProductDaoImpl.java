package com.advancejava.ShoppingCartApplication.daoimpl;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.advancejava.ShoppingCartApplication.beans.Product;
import com.advancejava.ShoppingCartApplication.dao.ProductDAO;

public class ProductDaoImpl implements ProductDAO {
	
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public int addProduct(Product prod) {
		return (Integer) hibernateTemplate.save(prod);
	}

	public Product findProductById(int productId) {
		String sql = "from Product";
		return (Product) hibernateTemplate.find(sql);
	}

	public int deleteProductById(int productId) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateProduct(Product prod) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return null;
	}

}
