package com.advancejava.ShoppingCartApplication.dao;

import java.util.List;

import com.advancejava.ShoppingCartApplication.beans.Product;

public interface ProductDAO {
	
	public int addProduct(Product prod);
	public Product findProductById(int productId);
	public int deleteProductById(int productId);
	public int updateProduct(Product prod);
	public List<Product> getAllProduct();

}
