package com.advance.training;

public class BankAccount {
	
	int accNo;
	String custName;
	String accType;
	float balance;
	
	public BankAccount() {
		this.accNo = 100;
		this.custName = "Virus";
		this.accType = "Savings";
		this.balance = 500;
	}
	
	public BankAccount(int accNo, String custName, String accType, float balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.balance = balance;
	}
	
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public void deposit(float amt) {
		if(amt < 0) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nfe) {
				System.out.println("Negative amount can not be deposited");
			}
		} else {
			balance = getBalance() + amt;
			System.out.println("Current balance is: " + balance);
		}
	}
	
	public void withdraw(float amt) {
		if(amt < 0) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nfe) {
				System.out.println("Insufficient balance. you can not withdraw");
			}
		} else {
			balance = getBalance() - amt;
			System.out.println("Current balance is: " + balance);
		}
	}
	
	public float getBalance() {
		if(balance < 1000) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nfe) {
				System.out.println("Balance is low: " + balance);
			}
		}
		return balance;
	}

	public void display() {
		System.out.println("Balance is: " + getBalance());
	}
	
	public static void main(String[] args) {
		BankAccount ba = new BankAccount();
		ba.deposit(2000);
		ba.display();
		ba.withdraw(500);
		ba.display();
		ba.getBalance();
		ba.display();
	}

}
