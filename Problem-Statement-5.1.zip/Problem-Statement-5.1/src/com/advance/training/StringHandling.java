package com.advance.training;

public class StringHandling {
	
	public static void main(String[] args) {
		String str = "JAVA is Simple";
		
		// UpperCase
		System.out.println("The Upper case is: " + str.toUpperCase());
		
		// LowerCase
		System.out.println("The Upper case is: " + str.toLowerCase());
		
		// 1st words of letter
		String[] words = str.split("\\s");
		for(String w : words) {
			System.out.println(w.charAt(0) + "\t");
		}
		
		// Change order
		String[] words1 = str.split("\\s");
		for(String w : words1) {
			System.out.println(w);
		}
		
		// Reverse the string
		StringBuilder sb = new StringBuilder(str);
		System.out.println("String: " + sb.toString());
		System.out.println("Reverse String: " + sb.reverse());
		
		// Total Length of the String
		System.out.println("Length of the string is: " + str.length());
		
		
	}
	
}
