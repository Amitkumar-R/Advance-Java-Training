package com.advance.training;

public class RectangleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Rectangle Object
		Rectangle rect1 = new Rectangle();
		System.out.println("Area of Rectangle1 is: " + rect1.getArea());
		
		Rectangle rect2 = new Rectangle(3.5, 4.2);
		System.out.println("Area of Rectangle2 is: " + rect2.getArea());	
		
		Rectangle rect3 = new Rectangle(2.4, 6.2);
		System.out.println("Area of Rectangle3 is: " + rect3.getArea());	
		
		Rectangle rect4 = new Rectangle(5.2, 2.9);
		System.out.println("Area of Rectangle4 is: " + rect4.getArea());	
		
		Rectangle rect5 = new Rectangle(1.4, 7.2);
		System.out.println("Area of Rectangle5 is: " + rect5.getArea());	
		
	}

}
