package com.advance.training;

public class Rectangle {
	
	private double length;
	private double width;
	
	// Constructor
	public Rectangle() {
		length = 0.0;
		width = 0.0;
	}
	
	public Rectangle(double l, double w) {
		length = l;
		width = w;
	}
	
	public void set(double l, double w) {
		length = l;
		width = w;
	}
	
	public double getArea() {
		return length * width;
	}
	
}
