package com.advance.training;

public class Fibonacci {
	
	public static void main(String[] args) {
		int count = 15;
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		
		for(int i = num1; i <= count; ++i) {
			System.out.println(num1 + " ");
			int sumOfPrevTwo = num1 + num2;
			num1 = num2;
			num2 = sumOfPrevTwo;
		}
		
		
	}

}
