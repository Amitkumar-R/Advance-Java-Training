package com.advance.training;

import java.util.HashMap;
import java.util.Map;

public class Decimal {
	
	public static String calculateFraction(int num, int den) {
		if(num == 0)
			return "0";
		if(den == 0)
			return "";
		
		StringBuilder res = new StringBuilder();
		if((num < 0) ^ (den < 0))
			res.append("-");
		
		num = Math.abs(num);
		den = Math.abs(den);
		
		long quo = num / den;
		long rem = num % den * 10;
		
		res.append(String.valueOf(quo));
		if(rem == 0)
			return res.toString();
		res.append(".");
		
		Map<Long, Integer> map = new HashMap<Long, Integer>();
		
		while(rem != 0) {
			if(map.containsKey(rem)) {
				int index = map.get(rem);
				String str1 = res.substring(0, index);
				String str2 = "(" + res.substring(index, res.length()) + ")";
				return str1 + str2;
			}
			map.put(rem, res.length());
			quo = rem / den;
			res.append(String.valueOf(quo));
			
			rem = (rem % den) * 10;
		}
		return res.toString();
	}
	
	public static void main(String[] args) {
		int num = 1;
		int den = 3;
		String resStr1 = calculateFraction(num, den);
		
		num = 1;
		den = 4;
		String resStr2 = calculateFraction(num, den);
		
		num = 1;
		den = 6;
		String resStr3 = calculateFraction(num, den);
		
		num = 1;
		den = 7;
		String resStr4 = calculateFraction(num, den);
		
		System.out.println(resStr1);
		System.out.println(resStr2);
		System.out.println(resStr3);
		System.out.println(resStr4);
	}

}
