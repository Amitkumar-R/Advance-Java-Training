package com.advance.training;

import java.util.Scanner;

public class Rectangle {

	private double length;
	private double width;
	Scanner sc = new Scanner(System.in);

	public Rectangle() {
		length = 1.0;
		width = 1.0;
	}

	public void setLength() {
		System.out.println("Enter the length: ");
		length = sc.nextDouble();
		if (length > 0.0 && length < 20.0) {
			setWidth();
		} else {
			System.out.println("Enter the valid number");
		}
	} 

	public void setWidth() {
		System.out.println("Enter the width: ");
		width = sc.nextDouble();
		if (width > 0.0 && width < 20.0) {
			System.out.println("Perimeter of Rectangle is: " + getPerimeter());
			System.out.println("Area of Rectangle is: " + getArea());
		} 
	}

	public double getPerimeter() {
		return 2 * (length + width);
	}

	public double getArea() {
		return length * width;
	}

}
