package com.advance.training;

public class Medicine {
	
	public void displayLabel() {
		System.out.println("Company : Life Line Pharma");
		System.out.println("Address : Bagalkote");
	}

}

class Tablet extends Medicine {
	public void displayLabel() {
		System.out.println("Store in a cool dry place");
	}
}

class Syrup extends Medicine {
	public void displayLabel() {
		System.out.println("Use as directed by Physician");
	}
}

class Ointment extends Medicine {
	public void displayLabel() {
		System.out.println("For external use only");
	}
}
